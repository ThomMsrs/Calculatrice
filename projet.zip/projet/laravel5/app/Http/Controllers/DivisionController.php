<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;

class AdditionController extends Controller
{
    public function getChiffre()
    {
		return view('division');
	}
	public function postChiffre(Request $request)
	{

		 $request[0]->input('num1');
		 $request[1]->input('num2');
		 if($request[1] == 0)
		{
			echo 'Division impossible par 0';
		}
		else 
		{	
		 $resultat = $request[0] / $request[1];
			echo 'Le quotient de ces deux nombres est '.$resultat; 
		}
	}
}
