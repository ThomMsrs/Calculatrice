<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;

class AdditionController extends Controller
{
    public function getChiffre()
    {
		return view('multiplication');
	}
	public function postChiffre(Request $request)
	{
		 $request[0]->input('num1');
		 $request[1]->input('num2');
		 $resultat = $request[0] * $request[1];
			echo 'Le produit de ces deux nombres est '.$resultat; 
	}
}
