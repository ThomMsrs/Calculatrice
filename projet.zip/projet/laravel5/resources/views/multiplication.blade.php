@extends('template')

@section('contenu')
    {!! Form::open(['url' => 'multiplication']) !!}
        {!! Form::label('num1', 'Entrez votre chiffre/nombre : ') !!}
        {!! Form::text('num1') !!}
        {!! Form::label('num2', 'Entrez votre chiffre/nombre : ') !!}
        {!! Form::text('num2') !!}
        {!! Form::submit('Calculer') !!}
    {!! Form::close() !!}
@endsection