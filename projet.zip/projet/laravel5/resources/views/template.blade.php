<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
</head>
<body>
	@yield('contenu')
</body>
</html>