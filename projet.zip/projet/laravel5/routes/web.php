<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'WelcomeController@index');
Route::get('addition', 'AdditionController@getChiffre');
Route::post('addition', 'AdditionController@postChiffre');

Route::get('soustraction', 'SoustractionController@getChiffre');
Route::post('soustraction', 'SoustractionController@postChiffre');

Route::get('multiplication', 'MultiplicaitonController@getChiffre');
Route::post('multiplication', 'MultiplicationController@postChiffre');

Route::get('division', 'DivisionController@getChiffre');
Route::post('division', 'DivisionController@postChiffre');