<?php $__env->startSection('contenu'); ?>
    <?php echo Form::open(['url' => 'addition']); ?>

        <?php echo Form::label('num1', 'Entrez votre chiffre/nombre : '); ?>

        <?php echo Form::text('num1'); ?>

        <?php echo Form::label('num2', 'Entrez votre chiffre/nombre : '); ?>

        <?php echo Form::text('num2'); ?>

        <?php echo Form::submit('Calculer'); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\projet\laravel5\resources\views/addition.blade.php ENDPATH**/ ?>