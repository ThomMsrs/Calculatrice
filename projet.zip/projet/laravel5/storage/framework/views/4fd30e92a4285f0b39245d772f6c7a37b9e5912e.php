<!doctype html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
</head>
<body>
	<?php echo $__env->yieldContent('contenu'); ?>
</body>
</html><?php /**PATH C:\wamp64\www\projet\laravel5\resources\views/template.blade.php ENDPATH**/ ?>